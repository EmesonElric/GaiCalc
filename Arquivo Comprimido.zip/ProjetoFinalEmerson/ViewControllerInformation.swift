//
//  ViewControllerInformation.swift
//  ProjetoFinalEmerson
//
//  Created by Treinamento on 02/06/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class ViewControllerInformation: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var infoTableView: UITableView!
    
     func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let celularReuso = "celulaReuso"
        let celula = tableView.dequeueReusableCell(withIdentifier: celularReuso, for: indexPath)
        celula.textLabel?.text = info [indexPath.row]
        return celula
    }
    

    var info: [String] = ["Abaixo de 18,5: Abaixo do Peso",
                          "Entre 18,6 e 24,9: Peso Ideal",
                          "Entre 25 e 29,9: Acima do Peso",
                          "Entre 30 a 34,9: Obesidade",
                          "Acima de 35: Obesidade Mórbida"]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.infoTableView.delegate = self
        self.infoTableView.dataSource = self
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
