//
//  ViewControllerAlcool.swift
//  ProjetoFinalEmerson
//
//  Created by Treinamento on 19/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class ViewControllerAlcool: UIViewController {
    
    
    @IBOutlet weak var precoAlcoolTextField: UITextField!
    @IBOutlet weak var precoGasolinaTextField: UITextField!
    @IBOutlet weak var resultadoLabel: UILabel!
    
    @IBAction func calcularCombustivel(_ sender: AnyObject) {
        var precoAlcool:Double = 0
        var precoGasolina: Double = 0
        var resultadoPreco: Double = 0
        
        if let precoAlcool = precoAlcoolTextField.text{
            if precoAlcool != ""{
                resultadoLabel.text = "Digite as informações"}
            }
    if let precoGasolina = precoGasolinaTextField.text{
        if precoGasolina != ""{
            resultadoLabel.text = "Digite as informações"}
    }

        
        
        if let resultadoAlcool = precoAlcoolTextField.text{
            if resultadoAlcool != "" {
                if let resultadoNumero = Double(resultadoAlcool){
                    precoAlcool = resultadoNumero
                }
            }
        }
        if let resultadoGasolina = precoGasolinaTextField.text{
            if resultadoGasolina != "" {
                if let resultadoNumero = Double(resultadoGasolina){
                    precoGasolina = resultadoNumero
                }
            }
        }
        
        
        
        resultadoPreco = precoAlcool / precoGasolina
        if resultadoPreco > 0.7{
            resultadoLabel.text = "Melhor utilizar Gasolina!!'"
        }else if resultadoPreco < 0.7 {
            resultadoLabel.text = "Melhor utilizar Álcool!!"
        } else {
            resultadoLabel.text = "Valores Invalidos"
        }
        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
