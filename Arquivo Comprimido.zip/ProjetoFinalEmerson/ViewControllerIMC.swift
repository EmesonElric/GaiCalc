//
//  ViewControllerIMC.swift
//  ProjetoFinalEmerson
//
//  Created by Treinamento on 02/06/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class ViewControllerIMC: UIViewController {
    
    
    @IBOutlet weak var pesoTextField: UITextField!
    @IBOutlet weak var alturaTextField: UITextField!
    @IBOutlet weak var resultadoLabel: UILabel!
    
    @IBAction func calcularIMC(_ sender: Any) {
        
        var imc: Double = 0
        var altura: Double = 0
        var peso: Double = 0
        
        if let resultadoIMC = pesoTextField.text{
            if resultadoIMC != ""{
                if let pesoNumero = Double(resultadoIMC){
                    peso = pesoNumero
                }
            }
        }
        if let resultadoIMC = alturaTextField.text{
            if resultadoIMC != ""{
                if let alturaNumero = Double(resultadoIMC){
                    altura = alturaNumero
                }
            }
        }
        
        imc = peso / (altura * altura)
        if imc <= 18.5 {
            resultadoLabel.text = "Abaixo do Peso"
        }else if (imc > 18.6 && imc <= 24.9){
            resultadoLabel.text = "Peso Ideal"
        }else if (imc > 25 && imc <= 29.9){
            resultadoLabel.text = "Acima do Peso"
        }else if (imc>30 && imc <= 34.9){
            resultadoLabel.text = "Obesidade"
        } else if (imc>34.9){
            resultadoLabel.text = "Obesidade Mórbida"
        }else{
            resultadoLabel.text = "Valores invalidos"
        }
        
            
    }
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
